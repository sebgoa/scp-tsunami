import threading

class S(threading._Semaphore):
    def __init__(self, val):
        threading.Semaphore.__init__(self, val)

    def getvalue(self):
        return self.__value

