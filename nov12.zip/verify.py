'''
Calculate the checksums of the transfered files to ensure they made it.
'''

import sys
from subprocess import Popen, PIPE, STDOUT

if len(sys.argv) < 4:
    print './verify.py <host file> <remote file> <local file>'
    sys.exit(1)

stdout = Popen('openssl md5 '+sys.argv[3], shell=True, stdout=PIPE).communicate()[0]
correct_cksum = stdout.split()[-1]

f = open(sys.argv[1], 'r')

procs = []
hostcount = 0
for hostn in f:
    host = hostn.strip()
    cmd = 'ssh %s openssl md5 %s' % (host, sys.argv[2])
    procs.append((host, Popen(cmd, shell=True, stdout=PIPE, stderr=STDOUT)))
    hostcount += 1

errors = 0
correct = 0
for host, p in procs:
    stdout = p.communicate()[0]
    cksum = stdout.split()[-1]
    if correct_cksum != cksum:
        print host+' error'
        errors += 1
    else:
        print host+' correct'
        correct += 1

print '%d / %d correct' % (correct, hostcount)
